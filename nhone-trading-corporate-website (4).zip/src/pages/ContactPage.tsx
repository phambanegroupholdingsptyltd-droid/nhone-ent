import { useState } from 'react';
import {
  Mail, Phone, Clock, Building2, Globe2,
  MessageCircle, Send
} from 'lucide-react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    service: '',
    email: '',
    phone: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this would send to an API/email service
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
    setFormData({ name: '', company: '', service: '', email: '', phone: '', message: '' });
  };

  const serviceOptions = [
    'Plant & Machinery Hire',
    'Transport & Logistics',
    'Mining Supplies',
    'Commodity Trading',
    'Fuel Supply Solutions',
    'Safety Equipment & PPE',
    'Civil Works & Construction',
    'General Supply & Delivery',
    'Other',
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative min-h-[40vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/contact-bg.jpg')" }}
        />
        <div className="absolute inset-0 bg-charcoal/80" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
          <span className="inline-block font-heading font-semibold text-teal-400 text-xs uppercase tracking-[0.3em] mb-4 animate-fade-in-up">
            Get In Touch
          </span>
          <h1 className="font-heading font-black text-4xl md:text-5xl lg:text-6xl text-white mb-6 animate-fade-in-up text-balance" style={{ animationDelay: '0.15s' }}>
            Let's <span className="text-teal-400">Work Together</span>
          </h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            Request a quote, enquire about compliance documents, or simply say hello — we respond within 24 hours.
          </p>
        </div>
      </section>

      {/* Contact Grid */}
      <section className="bg-off-white py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-3">
              <div className="bg-white rounded-2xl border border-black/5 p-8 md:p-10 shadow-sm">
                <h2 className="font-heading font-bold text-charcoal text-2xl mb-2">Send Us a Message</h2>
                <p className="text-charcoal/50 text-sm mb-8">Fill in the form below and we'll get back to you promptly.</p>

                {submitted ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-4">
                      <Send size={28} className="text-teal-500" />
                    </div>
                    <h3 className="font-heading font-bold text-charcoal text-xl mb-2">Message Sent!</h3>
                    <p className="text-charcoal/50">We'll get back to you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Full Name *</label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Company / Mine</label>
                        <input
                          type="text"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm"
                          placeholder="Company name"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Email</label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm"
                          placeholder="email@company.com"
                        />
                      </div>
                      <div>
                        <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Phone</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm"
                          placeholder="Your phone number"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Service Needed *</label>
                      <select
                        required
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm"
                      >
                        <option value="">Select a service</option>
                        {serviceOptions.map((opt) => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-charcoal/70 text-sm font-medium mb-1.5">Message *</label>
                      <textarea
                        required
                        rows={5}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 bg-off-white border border-black/10 rounded-lg text-charcoal focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-colors text-sm resize-none"
                        placeholder="Tell us about your requirements..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full sm:w-auto px-8 py-3.5 bg-teal-500 hover:bg-teal-600 text-charcoal font-heading font-bold rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-teal-500/25 inline-flex items-center justify-center gap-2"
                    >
                      Send Message
                      <Send size={16} />
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Contact Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Direct Contact */}
              <div className="bg-white rounded-2xl border border-black/5 p-8 shadow-sm">
                <h3 className="font-heading font-bold text-charcoal text-lg mb-6">Direct Contact</h3>
                <div className="space-y-5">
                  <a href="mailto:ntsakonhone01@gmail.com" className="flex items-start gap-3 group">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0 group-hover:bg-teal-500 transition-colors">
                      <Mail size={18} className="text-teal-500 group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Email 1</div>
                      <div className="text-charcoal font-medium text-sm">ntsakonhone01@gmail.com</div>
                    </div>
                  </a>
                  <a href="mailto:vhuthuhawetshikomba18@gmail.com" className="flex items-start gap-3 group">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0 group-hover:bg-teal-500 transition-colors">
                      <Mail size={18} className="text-teal-500 group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Email 2</div>
                      <div className="text-charcoal font-medium text-sm">vhuthuhawetshikomba18@gmail.com</div>
                    </div>
                  </a>
                  <a href="tel:0625041508" className="flex items-start gap-3 group">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0 group-hover:bg-teal-500 transition-colors">
                      <Phone size={18} className="text-teal-500 group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Cellphone 1</div>
                      <div className="text-charcoal font-medium text-sm">062 504 1508</div>
                    </div>
                  </a>
                  <a href="tel:0662246016" className="flex items-start gap-3 group">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0">
                      <Phone size={18} className="text-teal-500 group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Cellphone 2</div>
                      <div className="text-charcoal font-medium text-sm">066 224 6016</div>
                    </div>
                  </a>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0">
                      <Globe2 size={18} className="text-teal-500" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Service Coverage</div>
                      <div className="text-charcoal font-medium text-sm">Across the country</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center shrink-0">
                      <Clock size={18} className="text-teal-500" />
                    </div>
                    <div>
                      <div className="text-charcoal/40 text-xs uppercase tracking-wider mb-0.5">Business Hours</div>
                      <div className="text-charcoal font-medium text-sm">Mon – Fri: 07:00 – 17:00</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Procurement Info */}
              <div className="bg-charcoal rounded-2xl border border-white/5 p-8">
                <h3 className="font-heading font-bold text-white text-lg mb-6 flex items-center gap-2">
                  <Building2 size={18} className="text-teal-400" />
                  Procurement Reference
                </h3>
                <div className="space-y-4">
                  <div>
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-1">CSD Supplier Number</div>
                    <div className="text-white font-medium text-sm">CS-xxxx</div>
                  </div>
                  <div>
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-1">Ivanplats JDE Address Number</div>
                    <div className="text-white font-medium text-sm">JDE-xxxx</div>
                  </div>
                  <div>
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-1">Company Registration</div>
                    <div className="text-white font-medium text-sm">2022/xxx/07</div>
                  </div>
                  <div>
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-1">B-BBEE Status</div>
                    <div className="text-teal-400 font-medium text-sm">Level 1 (135% Recognition)</div>
                  </div>
                </div>
              </div>

              {/* WhatsApp */}
              <a
                href="https://wa.me/27625041508?text=Hello%20Nhone%20Trading%2C%20I%27d%20like%20to%20enquire%20about%20your%20services."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-6 bg-green-600 hover:bg-green-700 rounded-2xl transition-colors group"
              >
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                  <MessageCircle size={24} className="text-white" />
                </div>
                <div>
                  <div className="text-white font-heading font-bold">Chat on WhatsApp</div>
                  <div className="text-white/70 text-xs">Quick response guaranteed</div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
