import {
  Target, Users, Award, ShieldCheck, BadgeCheck,
  Building2, FileCheck, GraduationCap, Heart,
  Mail, Phone, Sparkles, TrendingUp,
  CheckCircle2, Star, Zap
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function AboutPage() {
  const storyRef = useInView(0.15);
  const missionRef = useInView(0.2);
  const valuesRef = useInView(0.15);
  const complianceRef = useInView(0.15);
  const mottoRef = useInView(0.2);

  return (
    <div className="overflow-hidden">
      {/* Hero — cinematic split */}
      <section className="relative min-h-[65vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/about-bg.jpg"
            alt="Aerial view of large-scale mining operations"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal via-charcoal/90 to-charcoal/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-charcoal/30" />
        </div>

        {/* Decorative diagonal accent */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-teal-500/5 clip-diagonal-tl" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 md:pb-28 w-full">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6 animate-fade-in-up">
              <div className="h-px w-12 bg-teal-400" />
              <span className="font-heading font-semibold text-teal-400 text-xs uppercase tracking-[0.3em]">
                Who We Are
              </span>
            </div>
            <h1 className="font-heading font-black text-4xl md:text-5xl lg:text-6xl text-white leading-[1.08] mb-6 animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
              Built by youth{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-teal-300">
                for the country
              </span>{' '}
              and the mining industry.
            </h1>
            <p className="text-white/60 text-lg md:text-xl max-w-2xl leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
              Nhone Trading Enterprise — a 100% Black Youth-Owned, B-BBEE Level 1 company delivering plant hire, logistics, mining supplies, commodity trading, and civil works across the country.
            </p>
            <div className="flex items-center gap-2 mt-8 animate-fade-in-up" style={{ animationDelay: '0.45s' }}>
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/10 border border-teal-500/30 rounded-lg text-teal-400 text-sm font-medium">
                <Award size={14} /> B-BBEE Level 1
              </span>
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white/60 text-sm font-medium">
                <BadgeCheck size={14} /> 100% Black Youth-Owned
              </span>
              <span className="hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white/60 text-sm font-medium">
                <FileCheck size={14} /> CSD Registered
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* The Founders — two-column story */}
      <section ref={storyRef.ref} className="relative bg-warm-white py-24 md:py-32 overflow-hidden">
        {/* Background accent */}
        <div className="absolute top-20 -right-40 w-[600px] h-[600px] bg-teal-500/5 rounded-full blur-3xl" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="mb-16">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-10 bg-teal-500" />
              <span className="font-heading font-semibold text-teal-600 text-xs uppercase tracking-[0.3em]">
                The Founders
              </span>
            </div>
            <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal">
              Two minds. One mission.
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Ntsako */}
            <div className={`group relative bg-white rounded-2xl overflow-hidden border border-black/5 transition-all duration-700 ${
              storyRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}>
              <div className="h-2 bg-gradient-to-r from-teal-500 to-teal-400" />
              <div className="p-8 md:p-10">
                <div className="flex items-start gap-5 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-teal-50 flex items-center justify-center shrink-0 group-hover:bg-teal-500 transition-colors duration-300">
                    <span className="font-heading font-black text-teal-600 text-xl group-hover:text-white transition-colors">N</span>
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-charcoal text-xl">Ntsako Nhone</h3>
                    <p className="text-teal-600 text-sm font-medium">Co-Founder & Director</p>
                  </div>
                </div>
                <div className="space-y-3 text-charcoal/60 leading-relaxed text-sm">
                  <p>
                    Holds a BCom Honours degree in Business Science from the University of the Witwatersrand. Brings deep expertise in accounting, economics, and entrepreneurship to every engagement.
                  </p>
                  <p>
                    Ntsako's vision drove Nhone Trading Enterprise from concept to compliance — building a procurement-ready company from the ground up with no inherited advantages, only determination.
                  </p>
                </div>
                <div className="mt-6 pt-6 border-t border-black/5 flex flex-wrap gap-2">
                  {['Accounting', 'Economics', 'Entrepreneurship'].map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-teal-50/80 text-teal-700 text-xs font-medium rounded-full">{skill}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Vhuthuhawe */}
            <div className={`group relative bg-white rounded-2xl overflow-hidden border border-black/5 transition-all duration-700 delay-150 ${
              storyRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}>
              <div className="h-2 bg-gradient-to-r from-rust to-rust-light" />
              <div className="p-8 md:p-10">
                <div className="flex items-start gap-5 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-rust/10 flex items-center justify-center shrink-0 group-hover:bg-rust transition-colors duration-300">
                    <span className="font-heading font-black text-rust text-xl group-hover:text-white transition-colors">V</span>
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-charcoal text-xl">Vhuthuhawe Tshikomba</h3>
                    <p className="text-rust text-sm font-medium">Co-Founder & Director</p>
                  </div>
                </div>
                <div className="space-y-3 text-charcoal/60 leading-relaxed text-sm">
                  <p>
                    Also holds a BCom Honours degree in Business Science from Wits. Brings complementary expertise in HR management, contract law, and operations to the team.
                  </p>
                  <p>
                    Vhuthuhawe ensures every contract, every compliance requirement, and every client relationship is handled with precision and professionalism — the backbone of operational credibility.
                  </p>
                </div>
                <div className="mt-6 pt-6 border-t border-black/5 flex flex-wrap gap-2">
                  {['HR Management', 'Contract Law', 'Operations'].map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-rust/10 text-rust text-xs font-medium rounded-full">{skill}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Combined skill bar */}
          <div className={`mt-12 p-6 bg-white rounded-2xl border border-black/5 flex flex-wrap items-center justify-center gap-4 md:gap-6 transition-all duration-700 delay-300 ${
            storyRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <span className="text-charcoal/40 text-xs font-heading uppercase tracking-wider">Combined Expertise</span>
            {['Wits BCom Honours', 'Business Science', 'Accounting', 'Economics', 'HR Management', 'Contract Law', 'Entrepreneurship', 'Operations'].map((skill) => (
              <div key={skill} className="flex items-center gap-1.5">
                <CheckCircle2 size={12} className="text-teal-500" />
                <span className="text-charcoal/60 text-xs font-medium">{skill}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Catalyst — why we exist */}
      <section className="relative bg-charcoal py-24 md:py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/hero-mining.jpg" alt="" className="w-full h-full object-cover opacity-10" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-10 bg-teal-400" />
              <span className="font-heading font-semibold text-teal-400 text-xs uppercase tracking-[0.3em]">
                The Catalyst
              </span>
              <div className="h-px w-10 bg-teal-400" />
            </div>
            <h2 className="font-heading font-black text-3xl md:text-4xl text-white">
              We saw a gap. We filled it.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {[
              {
                icon: Sparkles,
                title: 'The Problem',
                desc: 'Mining and industrial operations needed a supply partner who was fully compliant, capable, and serious about quality — not just a directory listing with a phone number.',
                bg: 'from-teal-500/20 to-teal-500/5',
              },
              {
                icon: Zap,
                title: 'The Response',
                desc: 'We built Nhone Trading Enterprise as a procurement-ready company from day one — B-BBEE Level 1, CSD registered, tax compliant, with the capability to deliver nationwide.',
                bg: 'from-white/10 to-white/5',
              },
              {
                icon: TrendingUp,
                title: 'The Result',
                desc: 'A trusted supplier to mining and industrial operations across the country — delivering plant hire, logistics, mining supplies, commodity trading, and civil works that keep operations running.',
                bg: 'from-teal-500/20 to-teal-500/5',
              },
            ].map((item) => (
              <div
                key={item.title}
                className={`group relative p-8 rounded-2xl border border-white/5 bg-gradient-to-b ${item.bg} hover:border-teal-500/30 transition-all duration-300`}
              >
                <div className="w-12 h-12 rounded-xl bg-teal-500/10 flex items-center justify-center mb-5 group-hover:bg-teal-500/20 transition-colors">
                  <item.icon size={24} className="text-teal-400" />
                </div>
                <h3 className="font-heading font-bold text-white text-lg mb-3">{item.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission — three pillars */}
      <section ref={missionRef.ref} className="relative bg-warm-white py-24 md:py-32 overflow-hidden">
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-teal-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-10 bg-teal-500" />
              <span className="font-heading font-semibold text-teal-600 text-xs uppercase tracking-[0.3em]">
                Our Mission
              </span>
              <div className="h-px w-10 bg-teal-500" />
            </div>
            <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal mb-4">
              Three pillars. One purpose.
            </h2>
            <p className="text-charcoal/50 max-w-xl mx-auto">
              Every decision, every contract, every delivery is guided by these core objectives.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: Target,
                title: 'Optimise Supply Chains',
                desc: 'Reducing procurement friction for mining operations — faster lead times, reliable deliveries, and fewer single points of failure.',
                accent: 'teal',
              },
              {
                icon: Users,
                title: 'Enhance Operational Efficiency',
                desc: 'The right equipment, materials, and logistics solutions at the right time. Minimising downtime is non-negotiable.',
                accent: 'rust',
              },
              {
                icon: Heart,
                title: 'Drive Sustainable Growth',
                desc: 'Building long-term client relationships that create real economic opportunity for youth across the country — beyond transactions.',
                accent: 'teal',
              },
            ].map((item, i) => (
              <div
                key={item.title}
                className={`group relative p-8 bg-white rounded-2xl border border-black/5 hover:border-teal-500/20 hover:shadow-xl hover:shadow-teal-500/5 transition-all duration-500 hover:-translate-y-1 ${
                  missionRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ transitionDelay: `${i * 150}ms` }}
              >
                {/* Corner accent */}
                <div className={`absolute top-0 right-0 w-16 h-16 ${
                  item.accent === 'teal'
                    ? 'bg-gradient-to-bl from-teal-500/10 to-transparent'
                    : 'bg-gradient-to-bl from-rust/10 to-transparent'
                } rounded-tr-2xl`} />

                <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 ${
                  item.accent === 'teal'
                    ? 'bg-teal-50 text-teal-500 group-hover:bg-teal-500 group-hover:text-white'
                    : 'bg-rust/10 text-rust group-hover:bg-rust group-hover:text-white'
                }`}>
                  <item.icon size={28} />
                </div>
                <h3 className="font-heading font-bold text-charcoal text-xl mb-3">{item.title}</h3>
                <p className="text-charcoal/60 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section ref={valuesRef.ref} className="bg-off-white py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="h-px w-10 bg-teal-500" />
                <span className="font-heading font-semibold text-teal-600 text-xs uppercase tracking-[0.3em]">
                  Our Values
                </span>
              </div>
              <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal mb-8">
                What drives every decision we make.
              </h2>

              <div className="space-y-6">
                {[
                  { icon: ShieldCheck, label: 'Compliance First', desc: 'Every document in order. Every standard met. We make procurement easy, not complicated.' },
                  { icon: Star, label: 'Excellence in Delivery', desc: 'On time, on spec, every time. Our reputation is built on reliability, not promises.' },
                  { icon: GraduationCap, label: 'Youth-Led Excellence', desc: 'We prove that young entrepreneurs can deliver world-class service to the mining industry.' },
                  { icon: Building2, label: 'Operational Thinking', desc: 'Relationships, not transactions. We build capacity through dependable service and collaboration.' },
                ].map((value, i) => (
                  <div
                    key={value.label}
                    className={`flex gap-4 transition-all duration-500 ${
                      valuesRef.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
                    }`}
                    style={{ transitionDelay: `${i * 120}ms` }}
                  >
                    <div className="w-10 h-10 rounded-lg bg-teal-500/10 flex items-center justify-center shrink-0 mt-0.5">
                      <value.icon size={20} className="text-teal-500" />
                    </div>
                    <div>
                      <h4 className="font-heading font-bold text-charcoal text-base mb-1">{value.label}</h4>
                      <p className="text-charcoal/50 text-sm leading-relaxed">{value.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Visual */}
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-charcoal">
                <img
                  src="/images/team.jpg"
                  alt="Nhone Trading Enterprise team — young professionals driving nationwide mining supply solutions"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent" />
              </div>
              {/* Floating quote card */}
              <div className="absolute -bottom-6 -left-6 md:-left-10 bg-white rounded-2xl shadow-xl p-6 max-w-xs border border-black/5">
                <div className="font-script text-2xl text-teal-500 mb-2">"Born to work hard!"</div>
                <p className="text-charcoal/50 text-xs leading-relaxed">
                  Not just a tagline — our operating principle. Every morning, every delivery, every client relationship.
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-teal-500 flex items-center justify-center">
                    <span className="text-white text-[8px] font-bold">NT</span>
                  </div>
                  <span className="text-charcoal/40 text-xs">Nhone Trading Enterprise</span>
                </div>
              </div>
              {/* Decorative element */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-teal-500/20 rounded-2xl -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Motto — dramatic full-width */}
      <section ref={mottoRef.ref} className="relative overflow-hidden min-h-[50vh] flex items-center">
        <div className="absolute inset-0 bg-charcoal" />
        <div className="absolute inset-0 opacity-20">
          <img src="/images/services-hero.jpg" alt="" className="w-full h-full object-cover" />
        </div>
        {/* Diagonal accents */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-teal-500 via-teal-400 to-transparent" />
        <div className="absolute bottom-0 right-0 w-full h-2 bg-gradient-to-l from-rust via-rust-light to-transparent" />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 text-center">
          <div className={`transition-all duration-1000 ${mottoRef.isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
            <GraduationCap size={56} className="text-teal-400 mx-auto mb-8" />
            <h2 className="font-script text-6xl md:text-8xl text-teal-400 mb-6 leading-none">
              "Born to work hard!"
            </h2>
            <div className="h-px w-24 bg-teal-400/40 mx-auto mb-8" />
            <p className="text-white/50 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
              We built this company from the ground up with nothing but determination, a Wits education, and a refusal to accept "small" as a limitation. Every contract we deliver proves that youth-owned doesn't mean youth in experience.
            </p>
          </div>
        </div>
      </section>

      {/* Compliance Table */}
      <section ref={complianceRef.ref} className="relative bg-warm-white py-24 md:py-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Left: text */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="h-px w-10 bg-teal-500" />
                <span className="font-heading font-semibold text-teal-600 text-xs uppercase tracking-[0.3em]">
                  Compliance & Credentials
                </span>
              </div>
              <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal mb-6">
                Procurement-ready. <br />
                <span className="text-teal-500">Every single time.</span>
              </h2>
              <p className="text-charcoal/60 leading-relaxed mb-8">
                Our compliance credentials aren't hidden in prose — they're front and centre. Procurement officers, tender evaluators, and supply chain managers can verify every status below.
              </p>
              <div className="p-6 bg-teal-50 rounded-2xl border border-teal-500/20">
                <p className="text-teal-800 text-sm font-medium">
                  <strong>B-BBEE Level 1 Contributor</strong> — 135% procurement recognition means every rand you spend with Nhone Trading Enterprise carries enhanced transformation value for your own B-BBEE scorecard.
                </p>
              </div>
            </div>

            {/* Right: table */}
            <div className={`transition-all duration-700 ${
              complianceRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}>
              <div className="bg-white rounded-2xl border border-black/5 overflow-hidden shadow-sm">
                {/* Header */}
                <div className="bg-charcoal px-6 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <ShieldCheck size={20} className="text-teal-400" />
                    <span className="font-heading font-semibold text-white text-sm">Verification Status</span>
                  </div>
                  <span className="px-2.5 py-1 bg-teal-500/20 text-teal-400 text-[10px] font-heading font-bold uppercase tracking-wider rounded-full">
                    All Verified
                  </span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-black/5">
                  {[
                    { icon: Award, label: 'B-BBEE Status', value: 'Level 1 Contributor', sub: '135% Procurement Recognition', status: 'CIPC Verified' },
                    { icon: Users, label: 'Ownership Structure', value: '100% Black Youth-Owned', sub: 'Full beneficial ownership', status: 'CIPC Verified' },
                    { icon: BadgeCheck, label: 'CSD Registration', value: 'Active Supplier', sub: 'Central Supplier Database', status: 'Active' },
                    { icon: FileCheck, label: 'Tax Compliance', value: 'Tax Clearance Current', sub: 'South African Revenue Service', status: 'SARS Verified' },
                    { icon: Building2, label: 'Company Registration', value: 'Pty Ltd (Active)', sub: 'CIPC Registered Entity', status: 'Active' },
                    { icon: GraduationCap, label: 'COIDA / UIF', value: 'Registered & Compliant', sub: 'Compensation Fund & Unemployment Insurance', status: 'Active' },
                  ].map((row, i) => (
                    <div
                      key={row.label}
                      className="px-6 py-4 flex items-center justify-between gap-4 hover:bg-teal-50/30 transition-colors"
                      style={{
                        animation: complianceRef.isVisible ? `fadeInUp 0.4s ease-out ${i * 80}ms both` : 'none',
                      }}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <row.icon size={18} className="text-teal-500 shrink-0" />
                        <div className="min-w-0">
                          <div className="font-heading font-semibold text-charcoal text-sm">{row.label}</div>
                          <div className="text-charcoal/60 text-sm">{row.value}</div>
                          <div className="text-charcoal/40 text-xs">{row.sub}</div>
                        </div>
                      </div>
                      <span className="shrink-0 px-3 py-1 bg-teal-50 text-teal-700 text-xs font-semibold rounded-full whitespace-nowrap">
                        {row.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Info */}
      <section className="bg-charcoal py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h3 className="font-heading font-bold text-white text-lg">Company Information</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: 'Company Name', value: 'Nhone Trading Enterprise (Pty) Ltd', icon: Building2 },
              { label: 'Registration Number', value: '2022/xxx/07', icon: FileCheck },
              { label: 'CSD Supplier Number', value: 'CS-xxxx', icon: BadgeCheck },
              { label: 'Tax Number', value: 'xxxx/xxx/xx', icon: FileCheck },
              { label: 'Email 1', value: 'ntsakonhone01@gmail.com', icon: Mail, link: true },
              { label: 'Email 2', value: 'vhuthuhawetshikomba18@gmail.com', icon: Mail, link: true },
              { label: 'Cellphone 1', value: '062 504 1508', icon: Phone, link: true },
              { label: 'Cellphone 2', value: '066 224 6016', icon: Phone, link: true },
            ].map((item) => (
              <div key={item.label} className="bg-white/5 rounded-xl border border-white/5 p-5">
                <div className="flex items-center gap-2 mb-2">
                  <item.icon size={14} className="text-teal-400" />
                  <span className="text-white/40 text-[10px] uppercase tracking-[0.15em] font-heading">{item.label}</span>
                </div>
                {item.link && item.icon === Mail ? (
                  <a href={`mailto:${item.value}`} className="text-white/80 text-sm hover:text-teal-400 transition-colors break-all">{item.value}</a>
                ) : item.link && item.icon === Phone ? (
                  <a href={`tel:${item.value.replace(/\s/g, '')}`} className="text-white/80 text-sm hover:text-teal-400 transition-colors">{item.value}</a>
                ) : (
                  <p className="text-white/80 text-sm">{item.value}</p>
                )}
              </div>
            ))}
            {/* Nationwide coverage */}
            <div className="sm:col-span-2 lg:col-span-3 bg-white/5 rounded-xl border border-white/5 p-5">
              <div className="flex items-center gap-2 mb-2">
                <Building2 size={14} className="text-teal-400" />
                <span className="text-white/40 text-[10px] uppercase tracking-[0.15em] font-heading">Service Coverage</span>
              </div>
              <p className="text-white/80 text-sm">Serving mining, industrial and commercial clients across the country.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
