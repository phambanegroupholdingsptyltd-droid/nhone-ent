import { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Camera } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const galleryImages = [
  { src: '/images/plant-hire.jpg', alt: 'Plant hire equipment - excavators and bulldozers at mining site', category: 'Plant Hire' },
  { src: '/images/logistics-trucks.jpg', alt: 'Logistics fleet - Hino tipper trucks and Volvo trailers', category: 'Logistics' },
  { src: '/images/site-work.jpg', alt: 'Underground mining site work with PPE-clad workers', category: 'Site Work' },
  { src: '/images/civil-works.jpg', alt: 'Civil works and earthmoving at mining site', category: 'Site Work' },
  { src: '/images/team.jpg', alt: 'Nhone Trading Enterprise team at mining operation', category: 'Team' },
  { src: '/images/mining-supplies.jpg', alt: 'Mining supplies warehouse with organized equipment', category: 'Plant Hire' },
  { src: '/images/hero-mining.jpg', alt: 'Mining dump trucks on red earth mining site', category: 'Logistics' },
  { src: '/images/about-bg.jpg', alt: 'Aerial view of open pit mining operations', category: 'Site Work' },
  { src: '/images/services-hero.jpg', alt: 'Various heavy machinery at mining operation', category: 'Plant Hire' },
  { src: '/images/contact-bg.jpg', alt: 'Mining site landscape at dusk', category: 'Site Work' },
  { src: '/images/hero-mining.jpg', alt: 'Mining dump truck hauling ore on red earth haul road', category: 'Logistics' },
];

const categories = ['All', 'Plant Hire', 'Logistics', 'Site Work', 'Team'];

export default function GalleryPage() {
  const [filter, setFilter] = useState('All');
  const [lightbox, setLightbox] = useState<number | null>(null);
  const gridRef = useInView(0.1);

  const filteredImages = filter === 'All'
    ? galleryImages
    : galleryImages.filter((img) => img.category === filter);

  const navigateLightbox = (dir: 'prev' | 'next') => {
    if (lightbox === null) return;
    const idx = filteredImages.findIndex((img) => img.src === galleryImages[lightbox]?.src);
    if (dir === 'prev') {
      setLightbox(filteredImages[(idx - 1 + filteredImages.length) % filteredImages.length] === undefined
        ? galleryImages.indexOf(filteredImages[(idx - 1 + filteredImages.length) % filteredImages.length])
        : galleryImages.indexOf(filteredImages[(idx - 1 + filteredImages.length) % filteredImages.length]));
    } else {
      setLightbox(galleryImages.indexOf(filteredImages[(idx + 1) % filteredImages.length]));
    }
  };

  // Keyboard navigation for lightbox
  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape') setLightbox(null);
    if (e.key === 'ArrowLeft') navigateLightbox('prev');
    if (e.key === 'ArrowRight') navigateLightbox('next');
  };

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative min-h-[40vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-charcoal via-charcoal-light to-charcoal" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
          <Camera size={40} className="text-teal-400 mx-auto mb-6" />
          <h1 className="font-heading font-black text-4xl md:text-5xl lg:text-6xl text-white mb-6 animate-fade-in-up">
            Our Work in <span className="text-teal-400">Action</span>
          </h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            Real photos from our mining sites, fleet operations and team — no stock imagery, no fluff.
          </p>
        </div>
      </section>

      {/* Gallery */}
      <section ref={gridRef.ref} className="bg-off-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-5 py-2 rounded-full font-heading font-medium text-sm transition-all duration-300 ${
                  filter === cat
                    ? 'bg-teal-500 text-charcoal'
                    : 'bg-white text-charcoal/60 border border-black/5 hover:border-teal-500/30 hover:text-teal-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredImages.map((img, i) => (
              <button
                key={`${img.src}-${i}`}
                onClick={() => setLightbox(galleryImages.indexOf(img))}
                className={`group relative aspect-[4/3] rounded-xl overflow-hidden cursor-pointer transition-all duration-500 ${
                  gridRef.isVisible ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <span className="inline-block px-3 py-1 bg-teal-500/90 text-charcoal text-xs font-medium rounded-full">
                    {img.category}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center"
          onClick={() => setLightbox(null)}
          onKeyDown={handleKeyDown}
          tabIndex={-1}
          role="dialog"
          aria-label="Image lightbox"
        >
          <button
            onClick={(e) => { e.stopPropagation(); setLightbox(null); }}
            className="absolute top-4 right-4 p-2 text-white/60 hover:text-white transition-colors z-10"
            aria-label="Close lightbox"
          >
            <X size={28} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); navigateLightbox('prev'); }}
            className="absolute left-4 p-3 text-white/60 hover:text-white transition-colors"
            aria-label="Previous image"
          >
            <ChevronLeft size={32} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); navigateLightbox('next'); }}
            className="absolute right-4 p-3 text-white/60 hover:text-white transition-colors"
            aria-label="Next image"
          >
            <ChevronRight size={32} />
          </button>
          <div
            className="max-w-4xl max-h-[85vh] w-full px-8"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={galleryImages[lightbox].src}
              alt={galleryImages[lightbox].alt}
              className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
            />
            <p className="text-white/60 text-sm text-center mt-4">
              {galleryImages[lightbox].alt}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
