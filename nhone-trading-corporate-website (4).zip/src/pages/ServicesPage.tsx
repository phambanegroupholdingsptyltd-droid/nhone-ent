import {
  Truck, Wrench, Pickaxe, Fuel, Shield, Hammer, Package, Store,
  ArrowRight
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

interface ServicesPageProps {
  onNavigate: (page: string) => void;
}

export default function ServicesPage({ onNavigate }: ServicesPageProps) {
  const servicesRef = useInView(0.1);

  const services = [
    {
      icon: Truck,
      title: 'Plant & Machinery Hire',
      description: 'Heavy plant and machinery hire for mining, construction and civil works operations. Our fleet includes excavators, dump trucks, bulldozers, water bowsers, and light plant equipment — all maintained to the highest safety standards.',
      details: ['CAT Excavators (various sizes)', 'Dump Trucks & Tipper Trucks', 'Bulldozers & Loaders', 'Water Bowsers', 'Light Plant Equipment'],
      image: '/images/plant-hire.jpg',
    },
    {
      icon: Wrench,
      title: 'Transport & Logistics',
      description: 'Comprehensive transport and logistics solutions for mining operations. We handle everything from heavy haulage and abnormal loads to regular supply runs — keeping your operation supplied and on schedule.',
      details: ['Heavy Haulage', 'Abnormal Load Transport', 'Supply Chain Logistics', 'Fleet Management', 'Site-to-Site Transport'],
      image: '/images/logistics-trucks.jpg',
    },
    {
      icon: Store,
      title: 'Retail, Motor Trade & Repair Work',
      description: 'We offer motor trade services including vehicle sales, servicing, and comprehensive repair work for mining fleet vehicles.',
      details: ['Vehicle Servicing', 'Repair & Maintenance', 'Motor Trade', 'Mining Fleet Support', 'Parts Supply'],
      image: '/images/plant-hire.jpg',
    },
    {
      icon: Pickaxe,
      title: 'Mining Supplies',
      description: 'Specialised mining equipment and materials delivered to your site. From drill bits and explosives handling materials to consumables and spare parts — we source and deliver what you need.',
      details: ['Drilling Equipment & Bits', 'Conveyor Belts & Parts', 'Mining Consumables', 'Spare Parts', 'Tools & Accessories'],
      image: '/images/mining-supplies.jpg',
    },
    {
      icon: Package,
      title: 'Commodity Trading',
      description: 'Sourcing, supplying and coordinating the movement of commodities for mining, industrial and commercial clients across the country.',
      details: ['Commodity Sourcing', 'Supplier Coordination', 'Bulk Supply Requests', 'Delivery Coordination', 'Trade Enquiries'],
      image: '/images/mining-supplies.jpg',
    },
    {
      icon: Fuel,
      title: 'Fuel Supply Solutions',
      description: 'Reliable fuel delivery to mining and industrial sites. We understand that fuel interruptions mean production losses — our supply chain ensures you never run dry.',
      details: ['Diesel Delivery', 'Fuel Management', 'Bulk Fuel Supply', 'Site-to-Site Fuel Transport', 'Fuel Quality Compliance'],
      image: '/images/logistics-trucks.jpg',
    },
    {
      icon: Shield,
      title: 'Safety Equipment & PPE',
      description: 'Full range of personal protective equipment and safety supplies for mining operations. We stock and deliver everything from hard hats and boots to specialised respiratory protection.',
      details: ['Hard Hats & Helmets', 'Safety Boots & Gloves', 'High-Visibility Clothing', 'Respiratory Protection', 'Fall Protection Equipment'],
      image: '/images/site-work.jpg',
    },
    {
      icon: Hammer,
      title: 'Civil Works & Construction',
      description: 'Mining-specific civil works including site preparation, road construction, drainage works, and earthmoving. Our teams deliver quality results on schedule and to specification.',
      details: ['Site Preparation', 'Access Road Construction', 'Drainage Works', 'Earthmoving & Blasting', 'Retaining Structures'],
      image: '/images/civil-works.jpg',
    },
    {
      icon: Package,
      title: 'General Supply & Delivery',
      description: 'General procurement and delivery services for mining operations. From office supplies to workshop consumables, we source and deliver a wide range of goods to keep your operation running smoothly.',
      details: ['Office & Workshop Supplies', 'Cleaning & Hygiene Products', 'Stationery & Consumables', 'Canteen & Catering Supplies', 'Ad-hoc Procurement'],
      image: '/images/mining-supplies.jpg',
    },
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative min-h-[50vh] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/services-hero.jpg')" }}
        />
        <div className="absolute inset-0 bg-charcoal/80" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
          <span className="inline-block font-heading font-semibold text-teal-400 text-xs uppercase tracking-[0.3em] mb-4 animate-fade-in-up">
            What We Deliver
          </span>
          <h1 className="font-heading font-black text-4xl md:text-5xl lg:text-6xl text-white mb-6 animate-fade-in-up text-balance" style={{ animationDelay: '0.15s' }}>
            Comprehensive{' '}
            <span className="text-teal-400">Mining Services</span>
          </h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            Nine core competencies delivering complete supply chain solutions to mining, industrial and commercial clients across the country.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section ref={servicesRef.ref} className="bg-off-white py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const IconComp = service.icon;
              const isEven = index % 2 === 0;
              return (
                <div
                  key={service.title}
                  className={`group relative overflow-hidden rounded-2xl border border-black/5 bg-white transition-all duration-500 ${
                    servicesRef.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  } ${isEven ? '' : 'lg:order-' + (index + 1)}`}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={service.image}
                      alt={`${service.title} service by Nhone Trading Enterprise`}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 to-transparent" />
                    <div className="absolute top-4 left-4 w-12 h-12 rounded-xl bg-teal-500/90 flex items-center justify-center">
                      <IconComp size={24} className="text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="font-heading font-bold text-charcoal text-xl mb-3">{service.title}</h3>
                    <p className="text-charcoal/60 text-sm leading-relaxed mb-4">{service.description}</p>
                    <ul className="space-y-1.5 mb-4">
                      {service.details.map((detail) => (
                        <li key={detail} className="flex items-center gap-2 text-charcoal/50 text-sm">
                          <span className="w-1.5 h-1.5 bg-teal-500 rounded-full shrink-0" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => onNavigate('contact')}
                      className="inline-flex items-center gap-2 text-teal-600 font-heading font-semibold text-sm hover:text-teal-700 transition-colors group/btn"
                    >
                      Request a Quote
                      <ArrowRight size={14} className="transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-teal-500 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal mb-4">
            Need a Service Not Listed?
          </h2>
          <p className="text-charcoal/70 text-lg mb-8">
            We source and deliver a wide range of mining supplies. If you don't see what you need, ask us.
          </p>
          <button
            onClick={() => onNavigate('contact')}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-charcoal hover:bg-charcoal-light text-white font-heading font-bold rounded-lg transition-all duration-300"
          >
            Get in Touch
            <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </section>
    </div>
  );
}
