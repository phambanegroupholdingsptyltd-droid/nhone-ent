import {
  ShieldCheck, BadgeCheck, Building2, FileCheck,
  Truck, HardHat, Wrench, Pickaxe, Fuel, Shield, Hammer, Package,
  ArrowRight, ChevronRight, Phone, Mail, Globe2
} from 'lucide-react';
import { useInView, useParallax } from '../hooks/useInView';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const heroOffset = useParallax(0.4);
  const trustRef = useInView(0.2);

  const services = [
    { icon: Truck, title: 'Plant & Machinery Hire', desc: 'Excavators, dump trucks, dozers and more for mining operations', color: 'teal' },
    { icon: Wrench, title: 'Transport & Logistics', desc: 'Heavy haulage, abnormal loads and fleet management', color: 'rust' },
    { icon: Pickaxe, title: 'Mining Supplies', desc: 'Specialised equipment and materials for mining operations', color: 'teal' },
    { icon: Package, title: 'Commodity Trading', desc: 'Sourcing and supplying commodities for industrial and mining clients', color: 'rust' },
    { icon: Fuel, title: 'Fuel Supply Solutions', desc: 'Reliable fuel delivery to mining and industrial sites', color: 'rust' },
    { icon: Shield, title: 'Safety Equipment & PPE', desc: 'Full range of personal protective equipment', color: 'teal' },
    { icon: Hammer, title: 'Civil Works & Construction', desc: 'Mining-specific civil works and earthmoving services', color: 'rust' },
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('/images/hero-mining.jpg')",
            transform: `translateY(${heroOffset}px) scale(1.1)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/80 via-charcoal/60 to-charcoal" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/60 to-transparent" />

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-40">
          <div className="max-w-3xl">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/10 border border-teal-500/30 rounded-full text-teal-400 text-xs font-heading font-semibold uppercase tracking-widest mb-6 animate-fade-in-up"
              style={{ animationDelay: '0.1s' }}
            >
              <BadgeCheck size={14} />
              B-BBEE Level 1 · 100% Black Youth-Owned
            </div>

            <h1
              className="font-heading font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white leading-[1.05] mb-6 animate-fade-in-up text-balance"
              style={{ animationDelay: '0.2s' }}
            >
              Trusted Partner to{' '}
              <span className="text-teal-400">Mining Operations</span>{' '}
              across the country
            </h1>

            <p
              className="text-white/70 text-lg md:text-xl max-w-2xl mb-2 leading-relaxed animate-fade-in-up"
              style={{ animationDelay: '0.35s' }}
            >
              Plant hire, logistics, mining supplies, commodity trading and civil works — delivered with compliance, capacity and commitment to clients across the country.
            </p>

            <p
              className="font-script text-3xl md:text-4xl text-teal-400 mb-10 animate-fade-in-up"
              style={{ animationDelay: '0.45s' }}
            >
              "Born to work hard!"
            </p>

            <div
              className="flex flex-col sm:flex-row gap-4 animate-fade-in-up"
              style={{ animationDelay: '0.55s' }}
            >
              <button
                onClick={() => onNavigate('contact')}
                className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-teal-500 hover:bg-teal-400 text-charcoal font-heading font-bold text-base rounded-lg transition-all duration-300 hover:shadow-xl hover:shadow-teal-500/30"
              >
                Request a Quote
                <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={() => onNavigate('services')}
                className="group inline-flex items-center justify-center gap-2 px-8 py-4 border border-white/20 hover:border-white/40 text-white font-heading font-semibold text-base rounded-lg transition-all duration-300 hover:bg-white/5"
              >
                View Our Services
                <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40 animate-float">
          <span className="text-xs font-heading tracking-widest uppercase">Scroll</span>
          <div className="w-5 h-8 border-2 border-white/30 rounded-full flex justify-center pt-1.5">
            <div className="w-1 h-2 bg-teal-400 rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section
        ref={trustRef.ref}
        className="relative bg-charcoal-light py-12 md:py-16"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {[
              { icon: BadgeCheck, label: 'B-BBEE Level 1', sub: '135% Procurement Recognition', color: 'teal' },
              { icon: Building2, label: '100% Black Youth-Owned', sub: 'CIPC Verified', color: 'teal' },
              { icon: FileCheck, label: 'CSD Registered', sub: 'Supplier Code Verified', color: 'teal' },
              { icon: ShieldCheck, label: 'Tax Compliant', sub: 'SARS Verified', color: 'teal' },
            ].map((badge, i) => (
              <div
                key={badge.label}
                className={`flex flex-col items-center text-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 hover:border-teal-500/30 transition-all duration-300 ${
                  trustRef.isVisible ? 'animate-count-up' : 'opacity-0'
                }`}
                style={{ animationDelay: trustRef.isVisible ? `${i * 120}ms` : '0ms' }}
              >
                <div className="w-14 h-14 rounded-xl bg-teal-500/10 flex items-center justify-center">
                  <badge.icon size={28} className="text-teal-400" />
                </div>
                <div>
                  <div className="font-heading font-bold text-white text-sm">{badge.label}</div>
                  <div className="text-white/40 text-xs mt-0.5">{badge.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Nhone */}
      <section className="relative bg-warm-white py-20 md:py-28 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <span className="font-heading font-semibold text-teal-600 text-xs uppercase tracking-[0.3em]">Our Differentiators</span>
            <h2 className="font-heading font-black text-3xl md:text-4xl lg:text-5xl text-charcoal mt-3 mb-4">
              Why Partner with <span className="text-teal-500">Nhone?</span>
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              We bring compliance, capacity, and genuine commitment to every mining operation we serve.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Globe2,
                title: 'Nationwide Coverage & Capacity',
                desc: 'We coordinate reliable supply, equipment and delivery solutions for mining and industrial clients across the country.',
              },
              {
                icon: ShieldCheck,
                title: 'Compliance & Safety',
                desc: 'B-BBEE Level 1, fully tax compliant, CSD registered — procurement-ready from day one.',
              },
              {
                icon: HardHat,
                title: 'Quality & Impactful Outcomes',
                desc: 'Every project delivered to specification, on time, and to the highest safety standards.',
              },
              {
                icon: Package,
                title: 'Comprehensive Integrated Solutions',
                desc: 'From plant hire to logistics, commodity trading and mining supplies — one partner, complete coverage.',
              },
            ].map((item) => (
              <div
                key={item.title}
                className="group p-6 bg-white rounded-2xl border border-black/5 hover:border-teal-500/30 hover:shadow-xl hover:shadow-teal-500/5 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4 group-hover:bg-teal-500 transition-colors duration-300">
                  <item.icon size={24} className="text-teal-500 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="font-heading font-bold text-charcoal text-lg mb-2">{item.title}</h3>
                <p className="text-charcoal/60 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="relative bg-charcoal py-20 md:py-28 overflow-hidden">
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-teal-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <span className="font-heading font-semibold text-teal-400 text-xs uppercase tracking-[0.3em]">What We Deliver</span>
            <h2 className="font-heading font-black text-3xl md:text-4xl lg:text-5xl text-white mt-3 mb-4">
              Our Core <span className="text-teal-400">Services</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => {
              const IconComp = service.icon;
              return (
                <button
                  key={service.title}
                  onClick={() => onNavigate('services')}
                  className="group text-left p-6 bg-white/5 rounded-2xl border border-white/5 hover:border-teal-500/40 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors duration-300 ${
                    service.color === 'teal'
                      ? 'bg-teal-500/10 group-hover:bg-teal-500'
                      : 'bg-rust/10 group-hover:bg-rust'
                  }`}>
                    <IconComp size={24} className={`transition-colors duration-300 ${
                      service.color === 'teal' ? 'text-teal-400 group-hover:text-white' : 'text-rust group-hover:text-white'
                    }`} />
                  </div>
                  <h3 className="font-heading font-bold text-white text-lg mb-2">{service.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed mb-4">{service.desc}</p>
                  <span className="inline-flex items-center gap-1 text-teal-400 text-sm font-medium group-hover:gap-2 transition-all duration-300">
                    Learn more <ArrowRight size={14} />
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Proof of work */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('/images/about-bg.jpg')",
          }}
        />
        <div className="absolute inset-0 bg-charcoal/85" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <BadgeCheck size={40} className="text-teal-400 mx-auto mb-6" />
          <h2 className="font-heading font-black text-3xl md:text-4xl lg:text-5xl text-white mb-6">
            Trusted to Deliver for Clients{' '}
            <span className="text-teal-400">Across the Country</span>
          </h2>
          <p className="text-white/70 text-lg leading-relaxed max-w-2xl mx-auto mb-8">
            We support mining and industrial clients nationwide with plant hire, logistics, commodity trading, mining supplies and civil works that keep operations running.
          </p>
          <div className="inline-flex items-center gap-4 px-6 py-3 bg-white/5 rounded-xl border border-white/10">
            <div className="flex -space-x-2">
              {['🚛', '⛏️', '🏗️'].map((emoji, i) => (
                <span key={i} className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center text-lg border-2 border-charcoal">
                  {emoji}
                </span>
              ))}
            </div>
            <span className="text-white/60 text-sm">Nationwide service delivery</span>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-500 py-16 md:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading font-black text-3xl md:text-4xl text-charcoal mb-4">
            Ready to Work Together?
          </h2>
          <p className="text-charcoal/70 text-lg mb-8 max-w-xl mx-auto">
            Let's discuss how Nhone Trading Enterprise can support your mining operation with compliant, capable supply solutions.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <button
              onClick={() => onNavigate('contact')}
              className="group inline-flex items-center gap-2 px-8 py-4 bg-charcoal hover:bg-charcoal-light text-white font-heading font-bold rounded-lg transition-all duration-300"
            >
              Request a Quote
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
            </button>
            <a
              href="https://wa.me/27625041508"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white/20 hover:bg-white/30 text-charcoal font-heading font-semibold rounded-lg transition-all duration-300"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              WhatsApp Us
            </a>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-charcoal/60 text-sm">
            <span className="flex items-center gap-2">
              <Mail size={14} /> ntsakonhone01@gmail.com / vhuthuhawetshikomba18@gmail.com
            </span>
            <span className="flex items-center gap-2">
              <Phone size={14} /> 062 504 1508 / 066 224 6016
            </span>
            <span className="flex items-center gap-2">
              <Globe2 size={14} /> Serving clients across the country
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
