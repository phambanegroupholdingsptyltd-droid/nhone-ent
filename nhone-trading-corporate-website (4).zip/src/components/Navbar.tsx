import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'services', label: 'Services' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-charcoal/95 backdrop-blur-md shadow-lg shadow-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNavigate('home')}
            className="flex items-center gap-2 group"
            aria-label="Nhone Trading Enterprise Home"
          >
            <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="transition-transform duration-300 group-hover:scale-105">
              {/* Peak/teal mountain mark */}
              <path d="M22 4L8 34H18L22 26L26 34H36L22 4Z" fill="#00C9A7" />
              <path d="M22 10L14 28H20L22 24L24 28H30L22 10Z" fill="#1a1a2e" opacity="0.3" />
              {/* Bird/swoosh */}
              <path d="M10 30C14 24 20 20 26 18C30 17 34 18 38 20" stroke="black" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            </svg>
            <div className="flex flex-col">
              <span className={`font-heading font-bold text-lg leading-tight transition-colors duration-300 ${
                scrolled ? 'text-white' : 'text-white'
              }`}>
                NHONE
              </span>
              <span className={`font-heading text-[10px] tracking-[0.3em] uppercase leading-tight transition-colors duration-300 ${
                scrolled ? 'text-teal-500' : 'text-teal-400'
              }`}>
                Trading Enterprise
              </span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`px-4 py-2 text-sm font-heading font-medium tracking-wide transition-all duration-300 rounded-lg ${
                  currentPage === item.id
                    ? 'text-teal-400 bg-teal-400/10'
                    : 'text-white/80 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => handleNavigate('contact')}
              className="ml-3 px-5 py-2.5 bg-teal-500 hover:bg-teal-600 text-charcoal font-heading font-semibold text-sm rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-teal-500/25"
            >
              Request a Quote
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-white hover:text-teal-400 transition-colors"
            aria-label={isOpen ? 'Close menu' : 'Open menu'}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <div
        className={`md:hidden fixed inset-0 top-16 bg-charcoal/98 backdrop-blur-lg transition-all duration-300 ${
          isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-6">
          {navItems.map((item, i) => (
            <button
              key={item.id}
              onClick={() => handleNavigate(item.id)}
              className={`font-heading text-2xl font-semibold tracking-wide transition-all duration-300 ${
                currentPage === item.id
                  ? 'text-teal-400'
                  : 'text-white/70 hover:text-white'
              }`}
              style={{
                animationDelay: `${i * 80}ms`,
                animation: isOpen ? `fadeInUp 0.4s ease-out ${i * 80}ms both` : 'none',
              }}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => handleNavigate('contact')}
            className="mt-4 px-8 py-3 bg-teal-500 hover:bg-teal-600 text-charcoal font-heading font-bold text-lg rounded-lg transition-all duration-300"
            style={{
              animation: isOpen ? 'fadeInUp 0.4s ease-out 400ms both' : 'none',
            }}
          >
            Request a Quote
          </button>
        </div>
      </div>
    </nav>
  );
}
