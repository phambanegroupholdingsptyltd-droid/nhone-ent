import { Globe2, Mail, Phone, Clock, ChevronRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-charcoal border-t border-white/5">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <svg width="40" height="40" viewBox="0 0 44 44" fill="none">
                <path d="M22 4L8 34H18L22 26L26 34H36L22 4Z" fill="#00C9A7" />
                <path d="M10 30C14 24 20 20 26 18C30 17 34 18 38 20" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" />
              </svg>
              <div>
                <div className="font-heading font-bold text-white text-lg">NHONE</div>
                <div className="font-heading text-[10px] tracking-[0.3em] uppercase text-teal-500">Trading Enterprise</div>
              </div>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-4">
              100% Black Youth-Owned, B-BBEE Level 1 trusted supplier to mining, industrial and commercial clients across the country.
            </p>
            <p className="font-script text-xl text-teal-400">"Born to work hard!"</p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About', 'Services', 'Gallery', 'Contact'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => onNavigate(item.toLowerCase())}
                    className="flex items-center gap-2 text-white/50 hover:text-teal-400 transition-colors text-sm group"
                  >
                    <ChevronRight size={14} className="transition-transform group-hover:translate-x-1" />
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Core Services</h4>
            <ul className="space-y-2">
              {['Plant & Machinery Hire', 'Transport & Logistics', 'Mining Supplies', 'Commodity Trading', 'Fuel Supply Solutions', 'Safety Equipment & PPE', 'Civil Works & Construction'].map((item) => (
                <li key={item}>
                  <span className="text-white/40 text-sm">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading font-semibold text-white text-sm uppercase tracking-wider mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Globe2 size={16} className="text-teal-500 mt-0.5 shrink-0" />
                <span className="text-white/50 text-sm">Serving clients across the country</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-teal-500 shrink-0" />
                <a href="mailto:ntsakonhone01@gmail.com" className="text-white/50 text-sm hover:text-teal-400 transition-colors">ntsakonhone01@gmail.com</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-teal-500 shrink-0" />
                <a href="mailto:vhuthuhawetshikomba18@gmail.com" className="text-white/50 text-sm hover:text-teal-400 transition-colors">vhuthuhawetshikomba18@gmail.com</a>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-teal-500 shrink-0" />
                <a href="tel:0625041508" className="text-white/50 text-sm hover:text-teal-400 transition-colors">062 504 1508</a>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-teal-500 shrink-0" />
                <a href="tel:0662246016" className="text-white/50 text-sm hover:text-teal-400 transition-colors">066 224 6016</a>
              </li>
              <li className="flex items-center gap-3">
                <Clock size={16} className="text-teal-500 shrink-0" />
                <span className="text-white/50 text-sm">Mon – Fri: 07:00 – 17:00</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/30 text-xs text-center md:text-left">
              © {new Date().getFullYear()} Nhone Trading Enterprise. All rights reserved. | Reg No: 2022/xxx/07 | CSD Supplier No: CS-xxxx
            </p>
            <div className="flex items-center gap-6">
              <span className="text-white/30 text-xs">B-BBEE Level 1 Contributor</span>
              <span className="text-teal-500/30">|</span>
              <span className="text-white/30 text-xs">100% Black Youth-Owned</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
