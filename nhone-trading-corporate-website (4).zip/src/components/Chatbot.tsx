import { useState } from 'react';
import { Send, X } from 'lucide-react';

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

type Message = {
  id: number;
  text: string;
  sender: 'bot' | 'user';
  options?: string[];
};

export default function Chatbot({ isOpen, onClose }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Welcome to Nhone Trading Enterprise! I'm your assistant. How can I help you today?",
      sender: 'bot',
      options: ['Request a Quote', 'Compliance Documents', 'Our Services', 'Talk to Someone'],
    },
  ]);
  const [input, setInput] = useState('');
  const [step, setStep] = useState(0);
  const [_quoteData, setQuoteData] = useState<{ company: string; service: string; location: string; urgency: string }>({ company: '', service: '', location: '', urgency: '' });

  const sendBotMessage = (text: string, options?: string[]) => {
    setMessages((prev) => [
      ...prev,
      { id: Date.now(), text, sender: 'bot', options },
    ]);
  };

  const handleOption = (option: string) => {
    // Add user message
    setMessages((prev) => [
      ...prev,
      { id: Date.now() - 1, text: option, sender: 'user' },
    ]);

    if (step === 0) {
      if (option === 'Request a Quote') {
        setStep(1);
        setTimeout(() => {
          sendBotMessage(
            "Great! Let me gather some details for your quote request. What's your company or mine name?",
            []
          );
        }, 500);
      } else if (option === 'Compliance Documents') {
        setStep(2);
        setTimeout(() => {
          sendBotMessage(
            "We maintain full compliance status:\n\n• B-BBEE Level 1 (135% verification)\n• 100% Black Youth-Owned\n• CSD Registered\n• Tax Compliant\n\nWhere should I send our compliance documents?",
            []
          );
        }, 500);
      } else if (option === 'Our Services') {
        setStep(3);
        setTimeout(() => {
          sendBotMessage(
            "We offer 8 core services:\n\n1. Plant & Machinery Hire\n2. Transport & Logistics\n3. Mining Supplies\n4. Fuel Supply Solutions\n5. Safety Equipment & PPE\n6. Civil Works & Construction\n7. Retail, Motor Trade & Repair\n8. General Supply & Delivery\n\nWhich service interests you?",
            ['Plant Hire', 'Logistics', 'Mining Supplies', 'Other']
          );
        }, 500);
      } else if (option === 'Talk to Someone') {
        setStep(99);
        setTimeout(() => {
          sendBotMessage(
            "I'll connect you with our team. You can reach us directly:\n\nEmail 1: ntsakonhone01@gmail.com\nEmail 2: vhuthuhawetshikomba18@gmail.com\nPhone 1: 062 504 1508\nPhone 2: 066 224 6016\n\nOr click below to start a WhatsApp chat.",
            ['Open WhatsApp']
          );
        }, 500);
      }
    } else if (step === 1) {
      setQuoteData((prev) => ({ ...prev, company: option }));
      setStep(1);
      setTimeout(() => {
        sendBotMessage("What service do you need?", [
          'Plant Hire', 'Logistics', 'Mining Supplies', 'Fuel Supply', 'PPE & Safety', 'Civil Works', 'Other'
        ]);
      }, 500);
    } else if (step === 2) {
      setTimeout(() => {
        sendBotMessage(
          "Please share the email address where we should send your compliance documents.",
          []
        );
      }, 500);
    } else if (step === 3) {
      setTimeout(() => {
        sendBotMessage(
          `Excellent choice! For ${option}, our team will prepare a detailed proposal. Would you like to request a full quote?`,
          ['Yes, Request Quote', 'Talk to Someone']
        );
      }, 500);
    } else if (step === 99 && option === 'Open WhatsApp') {
      window.open('https://wa.me/27625041508', '_blank');
    }
  };

  const handleSend = () => {
    if (!input.trim()) return;

    setMessages((prev) => [
      ...prev,
      { id: Date.now() - 1, text: input, sender: 'user' },
    ]);

    const userMsg = input.trim();

    if (step === 1) {
      // Quote flow
      const lastMsg = messages[messages.length - 1]?.text || '';
      if (lastMsg.includes('company')) {
        setQuoteData((prev) => ({ ...prev, company: userMsg }));
        setTimeout(() => {
          sendBotMessage("What service do you need?", [
            'Plant Hire', 'Logistics', 'Mining Supplies', 'Fuel Supply', 'PPE & Safety', 'Civil Works', 'Other'
          ]);
        }, 500);
      } else if (lastMsg.includes('service')) {
        setQuoteData((prev) => ({ ...prev, service: userMsg }));
        setTimeout(() => {
          sendBotMessage("Where is the site located?", []);
        }, 500);
      } else {
        setQuoteData((prev) => ({ ...prev, location: userMsg }));
        setTimeout(() => {
          sendBotMessage("How urgent is this request?", ['Urgent (within a week)', 'Normal (within a month)', 'Planning stage']);
        }, 500);
      }
    } else if (step === 2) {
      setTimeout(() => {
        sendBotMessage(
          `Thank you! Our compliance documents will be sent to ${userMsg} shortly. Is there anything else I can help with?`,
          ['Request a Quote', 'Our Services', 'Talk to Someone']
        );
        setStep(0);
      }, 500);
    }

    setInput('');
  };

  const lastMessage = messages[messages.length - 1];

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-20 right-4 md:bottom-6 md:right-6 w-[calc(100%-2rem)] max-w-sm bg-charcoal border border-white/10 rounded-2xl shadow-2xl shadow-black/50 z-50 overflow-hidden animate-scale-in">
      {/* Header */}
      <div className="bg-teal-500 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-charcoal rounded-full flex items-center justify-center">
            <span className="text-teal-400 font-bold text-xs">NT</span>
          </div>
          <div>
            <div className="font-heading font-semibold text-charcoal text-sm">Nhone Assist</div>
            <div className="text-charcoal/60 text-xs flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-charcoal/40 rounded-full inline-block"></span>
              Online
            </div>
          </div>
        </div>
        <button onClick={onClose} className="text-charcoal/60 hover:text-charcoal transition-colors">
          <X size={18} />
        </button>
      </div>

      {/* Messages */}
      <div className="h-72 overflow-y-auto p-4 space-y-3">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm whitespace-pre-wrap ${
                msg.sender === 'user'
                  ? 'bg-teal-500 text-charcoal rounded-br-md'
                  : 'bg-white/10 text-white/90 rounded-bl-md'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {/* Options */}
        {lastMessage?.options && lastMessage.sender === 'bot' && (
          <div className="flex flex-wrap gap-2 mt-2">
            {lastMessage.options.map((opt) => (
              <button
                key={opt}
                onClick={() => handleOption(opt)}
                className="px-3 py-1.5 bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-medium rounded-full hover:bg-teal-500/20 transition-colors"
              >
                {opt}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-white/5 p-3">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-teal-500/50"
          />
          <button
            onClick={handleSend}
            className="p-2 bg-teal-500 hover:bg-teal-600 text-charcoal rounded-lg transition-colors"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
